import Foundation

 






enum Planet {
     case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune
 }
