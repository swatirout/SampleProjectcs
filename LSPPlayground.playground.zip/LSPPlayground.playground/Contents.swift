import UIKit
//before LSP
//class Rectangle{
//    var width:Double = 0
//    var length:Double = 0
//    var area:Double{
//        return width * length
//    }
//}
//class Square:Rectangle{
//    override var width: Double{
//        didSet{
//            length = width
//        }
//    }
//}
//
//let objRectangle = Rectangle()
//objRectangle.length = 5
//objRectangle.width = 3
//
//debugPrint("arrea of rectangle = \(objRectangle.area)")
//let objSquare = Square()
//objSquare.width = 3
//debugPrint("area of square = \(objSquare.area)")

//After LSP Applied
protocol Shape{
    var area:Double { get }
}
class Rectangle:Shape{
    var width:Double = 0
    var length:Double = 0
    var area:Double{
        return width * length
    }
}
class Square:Shape{
        var width:Double = 0
    var area: Double{
        return pow(width, 2)
    }
}

let objRectangle = Rectangle()
objRectangle.length = 5
objRectangle.width = 3

debugPrint("arrea of rectangle = \(objRectangle.area)")
let objSquare = Square()
objSquare.width = 3
debugPrint("area of square = \(objSquare.area)")
